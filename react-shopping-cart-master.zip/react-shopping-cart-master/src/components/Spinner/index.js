import React from 'react';

import './style.scss';

export default () => (
  <div className="spinner lds-ring">
    <div />
    <div />
    <div />
    <div />
  </div>
);
